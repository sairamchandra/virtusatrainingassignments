package com.test;

import java.util.*;

public class Reverse{

public static void main(String args[]){

String name="here is my string";

StringBuilder strb=new StringBuilder(name);

System.out.println(strb.reverse().toString());

}

}